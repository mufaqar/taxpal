# TaxPal

NextJs with Tailwindcss and WP Headless CMS

## application status

[![Netlify Status](https://api.netlify.com/api/v1/badges/51c68e04-123d-4c92-ac0c-04d5290c7408/deploy-status)](https://app.netlify.com/sites/taxpal/deploys)
